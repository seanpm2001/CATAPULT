import { OnoConstructor } from "./types";
declare const constructor: OnoConstructor;
export { constructor as Ono };
