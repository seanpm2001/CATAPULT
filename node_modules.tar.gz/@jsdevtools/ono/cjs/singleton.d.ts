import { OnoSingleton } from "./types";
declare const singleton: OnoSingleton;
export { singleton as ono };
