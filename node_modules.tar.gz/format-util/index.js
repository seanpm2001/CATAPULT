module.exports = require('util').format;
