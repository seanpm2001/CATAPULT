'use strict'
var colorSupport = require('color-support')

module.exports = colorSupport().hasBasic
